## This Repository is no longer supported for updates to the Documentation <br> Documentation has been brought in-house <br>
 Documentation is available here: Select `View Documentation` <br>
 https://www.creditsafe.com/us/en/enterprise/integrations/company-data-api.html


# Creditsafe Connect API - Documentation
Documentation for using Creditsafe Connect API 


## Owner
Administrator: Creditsafe Technical Author 
